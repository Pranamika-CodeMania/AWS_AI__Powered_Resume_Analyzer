
Screenshot for the Lambda Function Test and the JSON Code for Testing.

{
  "Records": [
    {
      "s3": {
        "bucket": {
          "name": "resume-analyzer-container"
        },
        "object": {
          "key": "Pranamika Paul_Cloud_Backend_AWS_AI_Engineer.png"
        }
      }
    }
  ]
}

[Attached](Test_Lambda_Function.png)

