s3://resume-analyzer-container/cloudwatch-logs-export/

{
  "resume_text": "EDUCATIONAL QUALIFICATIONS\nSI No.\nDegree /\nUniversity / Board\nCollege / School\nPassing Year\nPercentage\nStd.\nScore\n1\nMaster of\nPuneUniversity\nSinhgadCollegeofEngineering\n2019\n80,01%\nEngineering\nThe AssamKaziranga\n2\nB. Tech\nTheAssamKazirangaUniversity\n2016\n81.11%\nUniversity\n(ECE)\n3\nClass XII\nC.B.S.E\nVivekanandaKendraVidyalaya\n2012\n70.01%\n4\nClass X\nSEBA\nSt.Stephen'sHighSchool\n2010\n78.05%\nAWARDS AND ACHIEVEMENTS\nReceived 'Monetary Award' for outstanding performance in multiple projects at BOSCH within 6 months of joining.\nReceived 'On Spot Delivery' certificate from TCS for remarkable contribution in business growth as a new employee.\n'Top Sales Executive' for consistent high performance at Maharashtra Institute of Technology.\nWon 'Women's Chess Championship' at TCS-Jaguar & Land Rover tournament.\nWon 'Women of the Match' in women's cricket at TCS-Jaguar & Land Rover tournament.\nRecognized as a Semi-Finalist in Table Tennis (TT) and Badminton Mixed, representing the department with pride and\nskill.\nPERSONAL DETAILS\nFather's Name\n: Ranjan Paul\nSpouse's Name\n: Gaurav Ghosh\nDateofBirth\n: 24thJanuary, 1994\nSex\n: Female\nNationality\n: Indian\nMaritalStatus\n: Married\nLanguagesKnow\n: English,Hindi,Bengali,Assamese\nPassport\nAvailable\nEmirates ID\nAvailable\nDECLARATION\nI hereby declare that the information given above by me is true and from best of my knowledge.\nDate:\nPlace: Dubai, UAE\nPranamika Paul\nPage 4 of 4\n",
  "skills": [
    {
      "Score": 0.6805006861686707,
      "Type": "OTHER",
      "Text": "1",
      "BeginOffset": 114,
      "EndOffset": 115
    },
    {
      "Score": 0.9963510036468506,
      "Type": "DATE",
      "Text": "2019",
      "BeginOffset": 169,
      "EndOffset": 173
    },
    {
      "Score": 0.9810711145401001,
      "Type": "QUANTITY",
      "Text": "80,01%",
      "BeginOffset": 174,
      "EndOffset": 180
    },
    {
      "Score": 0.63474440574646,
      "Type": "ORGANIZATION",
      "Text": "AssamKaziranga",
      "BeginOffset": 197,
      "EndOffset": 211
    },
    {
      "Score": 0.7227239608764648,
      "Type": "OTHER",
      "Text": "2\nB.",
      "BeginOffset": 212,
      "EndOffset": 216
    },
    {
      "Score": 0.6514724493026733,
      "Type": "ORGANIZATION",
      "Text": "Tech",
      "BeginOffset": 217,
      "EndOffset": 221
    },
    {
      "Score": 0.5263406038284302,
      "Type": "ORGANIZATION",
      "Text": "TheAssamKazirangaUniversity",
      "BeginOffset": 222,
      "EndOffset": 249
    },
    {
      "Score": 0.9969839453697205,
      "Type": "DATE",
      "Text": "2016",
      "BeginOffset": 250,
      "EndOffset": 254
    },
    {
      "Score": 0.9574154019355774,
      "Type": "QUANTITY",
      "Text": "81.11%",
      "BeginOffset": 255,
      "EndOffset": 261
    },
    {
      "Score": 0.3756725490093231,
      "Type": "OTHER",
      "Text": "ECE",
      "BeginOffset": 274,
      "EndOffset": 277
    },
    {
      "Score": 0.9245060086250305,
      "Type": "OTHER",
      "Text": "3\nClass XII",
      "BeginOffset": 279,
      "EndOffset": 290
    },
    {
      "Score": 0.46791067719459534,
      "Type": "OTHER",
      "Text": "C.B.S.E",
      "BeginOffset": 291,
      "EndOffset": 298
    },
    {
      "Score": 0.9956830739974976,
      "Type": "DATE",
      "Text": "2012",
      "BeginOffset": 326,
      "EndOffset": 330
    },
    {
      "Score": 0.8719760179519653,
      "Type": "QUANTITY",
      "Text": "70.01%",
      "BeginOffset": 331,
      "EndOffset": 337
    },
    {
      "Score": 0.8446928262710571,
      "Type": "OTHER",
      "Text": "4\nClass X",
      "BeginOffset": 338,
      "EndOffset": 347
    },
    {
      "Score": 0.5324763059616089,
      "Type": "ORGANIZATION",
      "Text": "SEBA",
      "BeginOffset": 348,
      "EndOffset": 352
    },
    {
      "Score": 0.99775630235672,
      "Type": "DATE",
      "Text": "2010",
      "BeginOffset": 376,
      "EndOffset": 380
    },
    {
      "Score": 0.9720932841300964,
      "Type": "QUANTITY",
      "Text": "78.05%",
      "BeginOffset": 381,
      "EndOffset": 387
    },
    {
      "Score": 0.9956150054931641,
      "Type": "ORGANIZATION",
      "Text": "BOSCH",
      "BeginOffset": 490,
      "EndOffset": 495
    },
    {
      "Score": 0.9902874231338501,
      "Type": "QUANTITY",
      "Text": "6 months",
      "BeginOffset": 503,
      "EndOffset": 511
    },
    {
      "Score": 0.6691107749938965,
      "Type": "OTHER",
      "Text": "Spot Delivery",
      "BeginOffset": 537,
      "EndOffset": 550
    },
    {
      "Score": 0.9970757961273193,
      "Type": "ORGANIZATION",
      "Text": "TCS",
      "BeginOffset": 569,
      "EndOffset": 572
    },
    {
      "Score": 0.9926753640174866,
      "Type": "ORGANIZATION",
      "Text": "Maharashtra Institute of Technology",
      "BeginOffset": 696,
      "EndOffset": 731
    },
    {
      "Score": 0.9786928296089172,
      "Type": "EVENT",
      "Text": "Women's Chess Championship",
      "BeginOffset": 738,
      "EndOffset": 764
    },
    {
      "Score": 0.7338828444480896,
      "Type": "EVENT",
      "Text": "TCS-Jaguar & Land Rover",
      "BeginOffset": 769,
      "EndOffset": 792
    },
    {
      "Score": 0.43602439761161804,
      "Type": "EVENT",
      "Text": "Women",
      "BeginOffset": 810,
      "EndOffset": 815
    },
    {
      "Score": 0.4221547245979309,
      "Type": "OTHER",
      "Text": "of",
      "BeginOffset": 816,
      "EndOffset": 818
    },
    {
      "Score": 0.6083440780639648,
      "Type": "EVENT",
      "Text": "Match",
      "BeginOffset": 823,
      "EndOffset": 828
    },
    {
      "Score": 0.882208526134491,
      "Type": "EVENT",
      "Text": "TCS-Jaguar &",
      "BeginOffset": 852,
      "EndOffset": 864
    },
    {
      "Score": 0.7199034690856934,
      "Type": "ORGANIZATION",
      "Text": "Land Rover",
      "BeginOffset": 865,
      "EndOffset": 875
    },
    {
      "Score": 0.5059583187103271,
      "Type": "TITLE",
      "Text": "Table",
      "BeginOffset": 921,
      "EndOffset": 926
    },
    {
      "Score": 0.9942373633384705,
      "Type": "PERSON",
      "Text": "Ranjan Paul",
      "BeginOffset": 1043,
      "EndOffset": 1054
    },
    {
      "Score": 0.9985510110855103,
      "Type": "PERSON",
      "Text": "Gaurav Ghosh",
      "BeginOffset": 1071,
      "EndOffset": 1083
    },
    {
      "Score": 0.8794246315956116,
      "Type": "DATE",
      "Text": "24thJanuary, 1994",
      "BeginOffset": 1098,
      "EndOffset": 1115
    },
    {
      "Score": 0.9559256434440613,
      "Type": "OTHER",
      "Text": "Indian",
      "BeginOffset": 1143,
      "EndOffset": 1149
    },
    {
      "Score": 0.9948404431343079,
      "Type": "OTHER",
      "Text": "English",
      "BeginOffset": 1190,
      "EndOffset": 1197
    },
    {
      "Score": 0.9955325126647949,
      "Type": "OTHER",
      "Text": "Hindi",
      "BeginOffset": 1198,
      "EndOffset": 1203
    },
    {
      "Score": 0.9929418563842773,
      "Type": "OTHER",
      "Text": "Bengali",
      "BeginOffset": 1204,
      "EndOffset": 1211
    },
    {
      "Score": 0.9856359958648682,
      "Type": "OTHER",
      "Text": "Assamese",
      "BeginOffset": 1212,
      "EndOffset": 1220
    },
    {
      "Score": 0.6761113405227661,
      "Type": "LOCATION",
      "Text": "Emirates",
      "BeginOffset": 1240,
      "EndOffset": 1248
    },
    {
      "Score": 0.8949967622756958,
      "Type": "LOCATION",
      "Text": "Dubai, UAE",
      "BeginOffset": 1382,
      "EndOffset": 1392
    },
    {
      "Score": 0.809959352016449,
      "Type": "PERSON",
      "Text": "Pranamika",
      "BeginOffset": 1393,
      "EndOffset": 1402
    },
    {
      "Score": 0.5136997103691101,
      "Type": "PERSON",
      "Text": "Paul",
      "BeginOffset": 1403,
      "EndOffset": 1407
    },
    {
      "Score": 0.5387827754020691,
      "Type": "QUANTITY",
      "Text": "Page",
      "BeginOffset": 1408,
      "EndOffset": 1412
    },
    {
      "Score": 0.5410254597663879,
      "Type": "OTHER",
      "Text": "4",
      "BeginOffset": 1413,
      "EndOffset": 1414
    },
    {
      "Score": 0.5956194996833801,
      "Type": "QUANTITY",
      "Text": "4",
      "BeginOffset": 1418,
      "EndOffset": 1419
    }
  ],
  "feedback": " Here are some suggestions to improve this resume:\n\n1. 
  Lead with a resume summary instead of just listing education. 
  Briefly highlight your skills, experience, and achievements relevant to the job.\n\n2.
  Move skills section higher up - after the summary. List key technical skills, soft skills, tools/software you have used.\n\n3. 
  Elaborate more on projects, accomplishments, responsibilities in each work experience. Quantify achievements with numbers/data where possible. \n\n4. 
  Add relevant certifications if any.\n\n5. 
  Standardize formatting and styling - consistent section headings, date formats, indentation, etc. Remove extraneous elements like page numbers.\n\n6. 
  Omit less relevant details - marital status, passport, awards not related to work. Can move some elements like languages, IT skills to a skills section.\n\n7. 
  Standardize capitalization of degree names, organizations, job titles. Correct typos/grammar errors.\n\n8"
}