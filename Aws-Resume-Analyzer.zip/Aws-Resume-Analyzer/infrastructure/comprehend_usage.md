
## Amazon Comprehend Usage

- Used to detect entities (skills, titles) from extracted resume text.
- LanguageCode: 'en'
- Functions used in Lambda

- comprehend:DetectSentiment
- comprehend:DetectEntities
- comprehend:DetectSyntax
- comprehend:DetectKeyPhrases