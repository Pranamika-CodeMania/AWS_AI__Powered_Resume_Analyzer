## S3 Bucket Configuration

- Bucket Name: resume-analyzer-container
- Trigger: Event Type → PUT (when new resume is uploaded)
- Destination: Triggers resumeAnalyzer_pranamika Lambda function
