
## Amazon Bedrock Usage

- Model: Anthropic Claude v2
- Model ID : anthropic.claude-v2:1
- Purpose: Generate feedback based on resume content
- Sample prompt: "Analyze this resume and provide improvement suggestions..."