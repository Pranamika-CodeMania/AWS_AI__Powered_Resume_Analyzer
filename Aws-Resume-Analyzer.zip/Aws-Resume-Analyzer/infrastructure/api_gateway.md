
## API Gateway Configuration

- API Type: REST
- Method: POST
- Triggered Lambda: resumeAnalyzer_pranamika
- URL: https://us-west-2.console.aws.amazon.com/apigateway/main/apis/0wzn5m8qce/resources?api=0wzn5m8qce&region=us-west-2